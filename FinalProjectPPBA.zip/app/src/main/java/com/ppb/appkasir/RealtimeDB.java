package com.ppb.appkasir;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RealtimeDB {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

}
